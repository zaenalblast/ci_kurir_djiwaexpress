<?php
 $this->load->view('template_register/head');
 $this->load->view('template_register/body');
 $this->load->view('template_register/footer');
?>