<?php
 $this->load->view('template_login/head');
 $this->load->view('template_login/body');
 $this->load->view('template_login/footer');
?>