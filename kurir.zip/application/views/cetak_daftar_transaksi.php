<?php 
 $this->load->view('template/head');
 $this->load->view('template_daftar_transaksi/cetak_daftar_transaksi');
 $this->load->view('template/js');
?>