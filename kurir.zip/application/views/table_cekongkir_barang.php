<?php
 $this->load->view('template/head');
 $this->load->view('template/sidebar');
 $this->load->view('template_cekongkir/cekongkir_barang');
 $this->load->view('template/footer');
 $this->load->view('template/js');
 

?>